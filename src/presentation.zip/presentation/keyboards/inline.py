from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import InlineKeyboardMarkup

def main_menu_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="👤 Профиль", callback_data="menu:profile")
    kb.button(text="🎯 Цель калорий", callback_data="menu:goal")
    kb.button(text="🔗 Реф. ссылка", callback_data="menu:reflink")
    kb.button(text="↩️ Отменить последнее", callback_data="menu:undo")
    kb.adjust(2, 2)
    return kb.as_markup()

def goal_input_kb() -> InlineKeyboardMarkup:
    kb = InlineKeyboardBuilder()
    kb.button(text="❌ Отмена", callback_data="goal:cancel")
    kb.button(text="⬅️ Назад", callback_data="menu:back")
    kb.adjust(2)
    return kb.as_markup()