# emgood/src/presentation/routers/chat.py
from aiogram import Router, F, types
from aiogram.types import CallbackQuery
from usecases.message_processing import MessageProcessor
from presentation.keyboards.common import day_keyboard

router = Router(name="chat")

def setup(processor: MessageProcessor) -> Router:
    @router.callback_query(F.data == "start_answering")
    async def on_start_answering(cb: CallbackQuery):
        text = await processor.enable_chat(cb.message.chat.id)
        await cb.message.answer(text)
        await cb.answer()

    @router.callback_query(F.data == "stop_answering")
    async def on_stop_answering(cb: CallbackQuery):
        text = await processor.disable_chat(cb.message.chat.id)
        await cb.message.answer(text)
        await cb.answer()

    @router.callback_query(F.data == "clear_day")
    async def on_clear_day(cb: CallbackQuery):
        reply = await processor.clear_day(cb.message.chat.id)
        show_undo = await processor.has_items(cb.message.chat.id) if hasattr(processor, "has_items") else True

        if isinstance(reply, dict) and "photo" in reply:
            await cb.message.answer_photo(
                types.FSInputFile(reply["photo"]),
                caption=reply.get("caption") or None,
                reply_markup=day_keyboard(show_undo)
            )
        else:
            await cb.message.answer(str(reply), reply_markup=day_keyboard(show_undo))
        await cb.answer()

    @router.callback_query(F.data == "undo_last")
    async def on_undo_last(cb: CallbackQuery):
        reply = await processor.undo_last(cb.message.chat.id)
        show_undo = await processor.has_items(cb.message.chat.id) if hasattr(processor, "has_items") else True

        if isinstance(reply, dict) and "photo" in reply:
            await cb.message.answer_photo(
                types.FSInputFile(reply["photo"]),
                caption=reply.get("caption") or None,
                reply_markup=day_keyboard(show_undo)
            )
        else:
            await cb.message.answer(str(reply), reply_markup=day_keyboard(show_undo))
        await cb.answer()

    @router.message(F.text)
    async def on_text(msg: types.Message):
        reply = await processor.process_user_text(msg.chat.id, msg.text or "")

        show_undo = True
        if hasattr(processor, "has_items"):
            try:
                show_undo = await processor.has_items(msg.chat.id)
            except Exception:
                show_undo = True

        if isinstance(reply, dict) and "photo" in reply:
            await msg.answer_photo(
                types.FSInputFile(reply["photo"]),
                caption=reply.get("caption") or None,
                reply_markup=day_keyboard(show_undo)
            )
        else:
            await msg.answer(str(reply), reply_markup=day_keyboard(show_undo))

    return router